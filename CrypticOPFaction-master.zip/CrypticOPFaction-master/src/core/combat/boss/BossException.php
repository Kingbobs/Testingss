<?php

declare(strict_types = 1);

namespace core\combat\boss;

use Exception;

class BossException extends Exception {

}