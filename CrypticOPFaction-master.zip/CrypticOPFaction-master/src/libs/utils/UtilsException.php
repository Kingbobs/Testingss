<?php

declare(strict_types = 1);

namespace libs\utils;

use Exception;

class UtilsException extends Exception {

}